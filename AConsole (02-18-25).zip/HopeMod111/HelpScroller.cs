﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace WildfrostHopeMod.CommandsConsole
{
    
    public partial class ConsoleMod
    {
        class HelpScroller : MonoBehaviour
        {
            /*public void Update()
            {
                if (Console.instance == null) return;
                if (!Console.instance.helpWindow.activeSelf) return;

                Console.instance.input.text

            }*/
        }
    }
}